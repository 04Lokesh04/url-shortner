# TODO: Implement your data models here
# Consider what data structures you'll need for:
# - Storing URL mappings
# - Tracking click counts
# - Managing URL metadata 

from datetime import datetime

url_store = {} 

def save_url_mapping(short_code, original_url):
    url_store[short_code] = {
        "url": original_url,
        "created_at": datetime.utcnow().isoformat(),
        "clicks": 0
    }

def get_url_data(short_code):
    return url_store.get(short_code)

def increment_clicks(short_code):
    if short_code in url_store:
        url_store[short_code]["clicks"] += 1