from flask import Flask, request, jsonify, redirect, abort
from app.utils import generate_short_code, is_valid_url
from app.models import save_url_mapping, get_url_data, increment_clicks

app = Flask(__name__)

@app.route('/')
def health_check():
    return jsonify({
        "status": "healthy",
        "service": "URL Shortener API"
    })

@app.route('/api/health')
def api_health():
    return jsonify({
        "status": "ok",
        "message": "URL Shortener API is running"
    })


@app.route('/api/shorten', methods=['POST'])
def shorten_url():
    data = request.get_json()
    original_url = data.get("url")

    if not original_url or not is_valid_url(original_url):
        return jsonify({"error": "Invalid or missing URL"}), 400

    short_code = generate_short_code()
    while get_url_data(short_code):
        short_code = generate_short_code()

    save_url_mapping(short_code, original_url)

    return jsonify({
        "short_code": short_code,
        "short_url": f"http://localhost:5000/{short_code}"
    }), 201

@app.route('/<short_code>', methods=['GET'])
def redirect_to_original(short_code):
    url_data = get_url_data(short_code)
    if not url_data:
        abort(404)

    increment_clicks(short_code)
    return redirect(url_data["url"])

@app.route('/api/stats/<short_code>', methods=['GET'])
def get_stats(short_code):
    url_data = get_url_data(short_code)
    if not url_data:
        abort(404)

    return jsonify({
        "url": url_data["url"],
        "clicks": url_data["clicks"],
        "created_at": url_data["created_at"]
    })


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)