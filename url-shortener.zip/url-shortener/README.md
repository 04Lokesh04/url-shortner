#  URL Shortener (Flask)

This is a refactored version of a legacy Flask-based user management API. The original project had issues in code structure, security, and maintainability. This version improves:
---

## Features

- Generate short URLs from long links
- Redirect to original URLs using
- Stats of the shortcode where click counts is shown
- All test cases written in `pytest` are passing
- Organized modular structure for maintainability

---

## Setup Instructions

### 1. Clone the repository
```bash
git clone <your-repo-url>
cd url-shortener
```
### 2. Create and activate a virtual environment
``` bash
python -m venv venv
# Activate on Windows
venv\Scripts\activate
```
```bash
### 3. Install dependencies

pip install -r requirements.txt
```
```bash
### 4. Run the application

python -m app.main
```
###  Folder Structure

url-shortener/
│
├── venv/                 
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── models.py
│   └── utils.py
│
├── tests/
│   └── test_basic.py
│
├── requirements.txt
└── README.md

## AI usage

- As a developer with a background in the MERN stack, this was my first time working with Flask in a modular backend application. To understand Flask’s conventions, best practices, and ecosystem better, I used AI (ChatGPT) selectively during the development process — especially in areas unfamiliar to me, such as Blueprint architecture, and unit testing with `pytest`.

### AI Tools Used
- **ChatGPT by OpenAI**: Used primarily for architectural suggestions.

### where AI helped
- Flask Structure 
- Testing 
- Offered suggestions for writing API test cases using Flask’s test client and `pytest`.
- Suggesting naming conventions and best practices

### Summary 
- AI was used as a supportive tool for familiarizing with flask framework
- All AI-generated code and suggestions were manually reviewed, edited, and tested to ensure functionality, accuracy, and maintainability.

### Author
 - Lokesh S
