import pytest
from app.main import app

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_health_check(client):
    response = client.get('/')
    assert response.status_code == 200
    data = response.get_json()
    assert data['status'] == 'healthy'
    assert data['service'] == 'URL Shortener API'


def test_shorten_url(client):
    res = client.post("/api/shorten", json={"url": "https://youtube.com"})
    assert res.status_code == 201
    data = res.get_json()
    assert "short_code" in data
    assert "short_url" in data

def test_invalid_url(client):
    res = client.post("/api/shorten", json={"url": "not-a-url"})
    assert res.status_code == 400
    assert "error" in res.get_json()

def test_redirect(client):
    shorten = client.post("/api/shorten", json={"url": "https://google.com"}).get_json()
    code = shorten["short_code"]
    res = client.get(f"/{code}", follow_redirects=False)
    assert res.status_code == 302

def test_stats(client):
    shorten = client.post("/api/shorten", json={"url": "https://openai.com"}).get_json()
    code = shorten["short_code"]
    client.get(f"/{code}")  # Trigger one click
    stats = client.get(f"/api/stats/{code}").get_json()
    assert stats["url"] == "https://openai.com"
    assert stats["clicks"] == 1
    assert "created_at" in stats